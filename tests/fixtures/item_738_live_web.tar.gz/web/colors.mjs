import { AGENT_PALETTE, agentColor } from './author-colors.mjs';

// The colors this reader chose for agents (docs/reading-colors.md, "Choosing
// an agent's color"), as Core keeps them: read with the colors view, changed
// with color.set. The page reads them when it opens and again whenever it is
// shown or focused, so a choice made on another device is there when the
// person comes back. Nothing here decides anything Core does not: a choice
// names a palette color or null, fenced on the revision last read.
const PAGE = 100;
const revision = value => Number.isSafeInteger(value) && value >= 0;

export class AgentColors {
  constructor({ api, instanceId, authority, id = () => crypto.randomUUID(), doc = globalThis.document, win = globalThis }) {
    if (!api || !instanceId || typeof authority !== 'function') throw Error('Agent colors need the instance and its authority.');
    Object.assign(this, { api, instanceId, authority, id });
    this.choices = new Map(); this.envelopes = new Map(); this.authorityKey = null; this.listeners = new Set(); this.palette = [...AGENT_PALETTE]; this.loaded = false; this.loading = null; this.again = false;
    const resume = () => { if (doc?.visibilityState !== 'hidden') this.load().catch(() => {}); };
    doc?.addEventListener?.('visibilitychange', resume); win?.addEventListener?.('focus', resume);
  }
  listen(listener) { this.listeners.add(listener); return () => this.listeners.delete(listener); }
  emit() { for (const listener of [...this.listeners]) listener(); }

  // The color an agent's cards wear for this reader: their choice, or the
  // agent's own.
  color(agentId) { return this.choices.get(agentId)?.color ?? agentColor(agentId); }
  chosen(agentId) { return this.choices.get(agentId)?.color ?? null; }

  // Every page of the reader's choices; a load asked for while one runs runs
  // once more after it, in the foreground if any asker wanted that. A read the
  // person waits on (the page opening, a picker) is foreground; a read on
  // focus is background. Rejects when the last read failed, and
  // then keeps what it had.
  load(readClass = 'background') {
    if (!['foreground', 'background'].includes(readClass)) throw Error('A read of the agent colors is foreground or background.');
    if (this.loading) { this.again = this.again === 'foreground' ? this.again : readClass; return this.loading; }
    this.again = readClass;
    this.loading = (async () => {
      // A read asked for while one fails still runs; the load answers how
      // the last read went.
      let failed = null;
      while (this.again) {
        const now = this.again; this.again = false;
        try { await this.readAll(now); failed = null; } catch (error) { failed = error; }
      }
      if (failed) throw failed;
    })().finally(() => { this.loading = null; this.again = false; });
    return this.loading;
  }
  async readAll(readClass) {
    const read = new Map();
    let cursor = null;
    do {
      const page = await this.api.view('colors', { limit: PAGE, ...(cursor === null ? {} : { cursor }) }, { readClass });
      if (page?.instance_id !== this.instanceId || !Array.isArray(page.items) || !Array.isArray(page.palette) ||
          !(page.next_cursor === null || typeof page.next_cursor === 'string' && page.next_cursor > (cursor ?? ''))) throw Error('The agent colors could not be confirmed.');
      if (page.palette.some(name => !AGENT_PALETTE.includes(name))) throw Error('Core names a color this page cannot draw.');
      for (const item of page.items) {
        if (typeof item?.actor_id !== 'string' || !item.actor_id || !revision(item.color_revision) ||
            !(item.color === null || page.palette.includes(item.color))) throw Error('An agent color could not be confirmed.');
        read.set(item.actor_id, { color: item.color, revision: item.color_revision });
      }
      this.palette = [...page.palette];
      cursor = page.next_cursor;
    } while (cursor !== null);
    // A read may have been answered before a choice this page then committed:
    // each agent keeps the newer revision. Core never deletes a choice (the
    // agent's own is held as null), so an agent the read lacks is one it had
    // not seen yet.
    for (const [agent, choice] of read) if (!(this.choices.get(agent)?.revision > choice.revision)) this.choices.set(agent, choice);
    this.loaded = true;
    this.emit();
  }

  // One envelope per agent, color and revision, made once and sent again as it
  // is until Core records an answer to it, so a press again after a lost
  // answer is the same request and Core answers it with what it recorded. One
  // made under another authority is dropped: it can only be refused.
  envelope(agentId, color) {
    const { authority_id, authority_epoch } = this.authority() ?? {}, key = JSON.stringify([authority_id, authority_epoch]);
    if (this.authorityKey !== key) { this.envelopes.clear(); this.authorityKey = key; }
    const at = this.choices.get(agentId)?.revision ?? 0, name = JSON.stringify([agentId, color, at]);
    if (!this.envelopes.has(name)) {
      this.envelopes.set(name, { v: 1, instance_id: this.instanceId, operation_id: this.id(), kind: 'color.set',
        target: { actor_id: agentId }, expected: { authority: { authority_id, authority_epoch }, color_revision: at }, args: { color } });
    }
    return { name, envelope: structuredClone(this.envelopes.get(name)) };
  }

  // Chooses color (a palette name, or null for the agent's own) for one agent.
  // Answers the receipt. A refusal for a stale revision means the choice
  // changed elsewhere: the page reads the choices again, while the person waits.
  async choose(agentId, color) {
    const { name, envelope } = this.envelope(agentId, color);
    const receipt = await this.api.command(envelope);
    if (receipt?.recorded === true && receipt.operation_id === envelope.operation_id &&
        this.envelopes.get(name)?.operation_id === envelope.operation_id) this.envelopes.delete(name);
    if (receipt?.status === 'committed') {
      // A request sent again is answered with what Core recorded then, which
      // a read since may have overtaken: as in readAll, the newer revision stays.
      const result = receipt.result;
      if (!(this.choices.get(agentId)?.revision >= result.color_revision)) this.choices.set(agentId, { color: result.color, revision: result.color_revision });
      this.emit();
    } else if (receipt?.error?.code === 'REVISION_CONFLICT') await this.load('foreground').catch(() => {});
    return receipt;
  }
}
