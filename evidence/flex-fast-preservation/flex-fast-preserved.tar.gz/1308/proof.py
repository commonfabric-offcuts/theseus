from __future__ import annotations
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/commonfabric/aim-worktrees/flex-1308-destination-kit472')
LOCK=Path('/Users/commonfabric/aim-next/tools/lane_lock.py')
name=sys.argv[1];folder=ROOT/name

def save(name,v): (folder/name).write_text(json.dumps(v,indent=2)+'\n')
def snapshot():
 paths=[Path(__file__),LOCK,REPO/'tools/destination_kit.py',REPO/'tools/deploy.py',REPO/'tests/test_destination_kit_1308.py',REPO/'docs/destination-kit-1308.md']
 blobs=ROOT/'input-blobs';blobs.mkdir(exist_ok=True)
 result={}
 for p in paths:
  b=p.read_bytes();h=hashlib.sha256(b).hexdigest();result[str(p)]={'bytes':len(b),'sha256':h};f=blobs/h
  if not f.exists():f.write_bytes(b)
 return result
if len(sys.argv)>2:
 while os.getloadavg()[0]>=12:time.sleep(1)
 before=snapshot();save('entry-inputs.json',before);save('entry.json',{'at_ms':time.time_ns()//1000000,'load':os.getloadavg(),'priority':os.getpriority(os.PRIO_PROCESS,0),'pid':os.getpid(),'pgid':os.getpgid(0),'python':sys.version})
 argv=['/usr/bin/python3','-X','pycache_prefix='+str(folder/'pycache'),'-I','-m','unittest','discover','-s','tests','-p','test_destination_kit_1308.py','-v']
 if name.startswith('inventory-'):
  argv=['/usr/bin/python3','-I',str(REPO/'tools/destination_kit.py'),'inventory','--landing-config','/Users/commonfabric/.config/theseus/landing.json','--repo','/Users/commonfabric/aim-next']
 save('body-argv.json',argv);p=subprocess.Popen(argv,cwd=REPO);save('body-owner.json',{'pid':p.pid,'pgid':os.getpgid(p.pid)});code=p.wait();after=snapshot();save('after-inputs.json',after);save('body-terminal.json',{'exit':code,'child_reaped':True,'unchanged':before==after,'ended_ms':time.time_ns()//1000000});raise SystemExit(code)
folder.mkdir(exist_ok=False);save('queued-inputs.json',snapshot());argv=['/usr/bin/python3','-I',str(LOCK),'run','--label','1308 '+name,'--','/usr/bin/nice','-n','15','/usr/bin/python3','-I',str(Path(__file__).resolve()),name,'entered'];save('argv.json',argv)
with (folder/'stdout').open('wb') as out,(folder/'stderr').open('wb') as err:
 start=time.time_ns()//1000000;p=subprocess.Popen(argv,stdout=out,stderr=err,start_new_session=True);save('ownership.json',{'supervisor':os.getpid(),'wrapper':p.pid,'pgid':p.pid,'start_ms':start});code=p.wait()
try:os.killpg(p.pid,0);empty=False
except ProcessLookupError:empty=True
save('terminal.json',{'exit':code,'wrapper_reaped':True,'group_empty':empty,'started_ms':start,'ended_ms':time.time_ns()//1000000});print(json.dumps({'name':name,'exit':code,'group_empty':empty}));print((folder/'stderr').read_text()[-5000:]);raise SystemExit(code)
