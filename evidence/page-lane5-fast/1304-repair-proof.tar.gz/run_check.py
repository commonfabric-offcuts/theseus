from __future__ import annotations
import hashlib,json,os,pathlib,subprocess,sys,time
E=pathlib.Path(__file__).resolve().parent
W=pathlib.Path('/Users/commonfabric/aim-worktrees/page-lane5-stage1304-472')
paths=['tools/stage_destination.py','tests/test_stage_destination_1304.py','docs/staging-command-pack-1304.md']
def inputs():
 out={}
 for rel in paths:
  data=(W/rel).read_bytes();h=hashlib.sha256(data).hexdigest();out[rel]=h
  dest=E/'blobs'/h;dest.parent.mkdir(exist_ok=True)
  if not dest.exists():dest.write_bytes(data)
 for label, path in [('harness/run_check.py',pathlib.Path(__file__)),('harness/installed-lane-lock.py',pathlib.Path('/Users/commonfabric/aim-next/tools/lane_lock.py'))]:
  data=path.read_bytes();h=hashlib.sha256(data).hexdigest();out[label]=h;dest=E/'blobs'/h;dest.parent.mkdir(exist_ok=True)
  if not dest.exists():dest.write_bytes(data)
 return out
if sys.argv[1]=='entry':
 a=E/sys.argv[2];source=sys.argv[3];entry=inputs();(a/'entry.json').write_text(json.dumps({'inputs':entry,'ms':int(time.time()*1000),'pid':os.getpid(),'nice':os.getpriority(os.PRIO_PROCESS,0),'load':os.getloadavg()}))
 if entry!=json.loads((a/'queued.json').read_text())['inputs']:raise SystemExit('SOURCE_CHANGED_WHILE_QUEUED')
 if os.getloadavg()[0]>=12:raise SystemExit('LOAD_NOT_ADMITTED')
 env=dict(os.environ,STAGE1304_SOURCE=source,STAGE1304_CACHE_RECEIPT=str(a/'effective-cache.json'))
 argv=['/usr/bin/python3','-I','-X','pycache_prefix='+str(a/'body-cache'),str(W/'tests/test_stage_destination_1304.py')]
 p=subprocess.Popen(argv,cwd=str(W),env=env);code=p.wait();after=inputs()
 (a/'child.json').write_text(json.dumps({'pid':p.pid,'exit':code,'argv':argv,'source':source,'end_ms':int(time.time()*1000),'inputs_equal':entry==after,'after':after}));raise SystemExit(code)
_,attempt,source=sys.argv;a=E/attempt;a.mkdir();queued=inputs();start=int(time.time()*1000)
(a/'queued.json').write_text(json.dumps({'inputs':queued,'ms':start,'load':os.getloadavg()}))
argv=['/usr/bin/python3','-I','/Users/commonfabric/aim-next/tools/lane_lock.py','run','--label','1304 '+attempt,'--','nice','-n','15','/usr/bin/python3','-I',str(__file__),'entry',attempt,source]
(a/'argv.json').write_text(json.dumps(argv));env=dict(os.environ,PYTHONPYCACHEPREFIX=str(a/'pycache'))
with (a/'output.txt').open('w') as out:
 p=subprocess.Popen(argv,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,env=env);code=p.wait()
ps=subprocess.check_output(['ps','-axo','pid,ppid,pgid,command'],text=True)
remaining=[line for line in ps.splitlines()[1:] if len(line.split())>2 and line.split()[2]==str(p.pid)]
receipt={'start_ms':start,'end_ms':int(time.time()*1000),'wrapper_pid':p.pid,'wrapper_exit':code,'remaining_original_group':remaining}
(a/'terminal.json').write_text(json.dumps(receipt));print(json.dumps(receipt));print((a/'output.txt').read_text())
